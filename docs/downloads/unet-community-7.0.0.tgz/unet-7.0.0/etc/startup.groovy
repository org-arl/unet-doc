def startupScript = new File(home, 'scripts/startup.groovy')

// use startup script, or default to the following
if (startupScript.exists()) run startupScript

// load SWIS configuration if unet-swis is available
try {
  Class.forName('org.arl.unet.swis.SwisShellExt')
  swisStartup()
} catch (ClassNotFoundException ex) {
  // unet-swis not present in this edition, quietly skip
}
