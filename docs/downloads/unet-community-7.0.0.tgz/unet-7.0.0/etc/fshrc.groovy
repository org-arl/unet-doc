import org.arl.unet.Services

def load(url, cond=null) {
  try {
    if (cond != null) {
      if (cond instanceof Services && !agentForService(cond)) return
      if (cond instanceof Closure && !cond()) return
    }
    run(url)
  } catch (FileNotFoundException ex) {
    log.warning "$url: file not found, skipping it!"
  } catch (ClassNotFoundException ex) {
    log.warning "$url: class not found, skipping it!"
  } catch (ex) {
    log.log(WARNING, "$url: loading failed", ex)
  }
}

home = System.getProperty('unet.home')?:'.'
home = new File(home).getCanonicalFile()
scripts = new File(home, 'scripts')

load 'cls://org.arl.unet.UnetShellExt'
load 'cls://org.arl.unet.device.DeviceShellExt',        Services.DEVICE_INFO
load 'cls://org.arl.unet.nodeinfo.NodeInfoShellExt',    Services.NODE_INFO
load 'cls://org.arl.unet.addr.ArpShellExt',             Services.ADDRESS_RESOLUTION
load 'cls://org.arl.unet.phy.PhysicalShellExt',         Services.PHYSICAL
load 'cls://org.arl.unet.localization.RangingShellExt', Services.RANGING
load 'cls://org.arl.unet.bb.BasebandShellExt',          Services.BASEBAND
load 'cls://org.arl.unet.mac.MacShellExt',              Services.MAC
load 'cls://org.arl.unet.net.RouterShellExt',           Services.ROUTING
load 'cls://org.arl.unet.net.RouteDiscoveryShellExt',   Services.ROUTE_MAINTENANCE
load 'cls://org.arl.unet.transport.TransportShellExt',  Services.TRANSPORT
load 'cls://org.arl.unet.remote.RemoteShellExt',        Services.REMOTE
load 'cls://org.arl.unet.scheduler.SchedulerShellExt',  Services.SCHEDULER
load 'cls://org.arl.unet.link.LinkTunerShellExt',       Services.LINK_TUNING
load 'cls://org.arl.unet.link.LinkShellExt',            Services.LINK
load 'cls://org.arl.unet.DatagramShellExt',             Services.DATAGRAM
load 'cls://org.arl.unet.profiles.ProfilesShellExt',    { agent('profiles').type }
load 'cls://org.arl.unet.utils.SpeedTestShellExt',      { agent('speedtest').type }

load 'cls://org.arl.unet.swis.SwisShellExt'
